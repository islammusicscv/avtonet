<?php
include_once "header.php";
?>

<h1>Demo stran</h1>

<a href="view.php?a=123">Vrednost</a>

<?php
include_once "footer.php";
?>