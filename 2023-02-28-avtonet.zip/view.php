<?php
include_once "header.php";
?>

<h1>View stran</h1>

<?php
$a = $_GET['b'];
echo $a;
?>

<?php
include_once "footer.php";
?>